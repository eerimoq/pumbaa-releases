Environment setup
=================

The first step is always to setup the `Pumbaa` environment. It's a
simple matter of sourcing a setup-script in the pumbaa root folder.

.. code-block:: text

   $ source setup.sh
