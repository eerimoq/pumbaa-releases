:mod:`struct` --- Interpret strings as packed binary data
=========================================================

.. module:: struct
   :synopsis: Interpret strings as packed binary data.

----------------------------------------------
