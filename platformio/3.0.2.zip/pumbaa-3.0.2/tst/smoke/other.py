def foo():
    return True
