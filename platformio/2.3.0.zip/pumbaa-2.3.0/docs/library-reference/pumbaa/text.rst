:mod:`text` --- Text parsing, editing and colorization
======================================================

.. module:: text
   :synopsis: Text parsing, editing and colorization.

Simba documentation: `text`_

----------------------------------------------


.. function:: text.emacs([path])

   Start the Emacs text editor. Automatically opens file at `path` if
   given.


.. _text: http://simba-os.readthedocs.io/en/latest/library-reference/text.html
