Examples
========

Below is a list of simple examples that are useful to understand the
basics of `Pumbaa`.

There are a lot more :github-tree:`examples<examples>` and
:github-tree:`unit tests<tst>` on Github that shows how to use most of
the `Pumbaa` modules.

.. toctree::
   :maxdepth: 1
   :glob:

   examples/*
