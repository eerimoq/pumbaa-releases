Developer Guide
===============

This guide is intended for developers of the Pumbaa Embedded
Programming Platform. Users are advised to read the :doc:`user-guide`
instead.

**Contents:**

.. toctree::
   :glob:   
   :maxdepth: 1

   developer-guide/releasing
