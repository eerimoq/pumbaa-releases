Documentation
=============

The documentation is generated to ``.html`` from ``.rst`` files using
`Sphinx<http://www.sphinx-doc.org>`.

.. code-block:: text

   cd .. && make doc && firefox doc/_build/html/index.html
