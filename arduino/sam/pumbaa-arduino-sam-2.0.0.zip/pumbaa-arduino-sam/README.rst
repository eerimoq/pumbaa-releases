|buildstatus|_
|codecov|_

About
=====

`Pumbaa` is `Python` on top of `Simba`. See
http://pumbaa.readthedocs.org for further details.

The implementation is a port of `MicroPython`, designed for embedded
devices with limited amount of RAM and code memory.

.. |buildstatus| image:: https://travis-ci.org/eerimoq/pumbaa.svg
.. _buildstatus: https://travis-ci.org/eerimoq/pumbaa

.. |codecov| image:: https://codecov.io/gh/eerimoq/pumbaa/branch/master/graph/badge.svg
.. _codecov: https://codecov.io/gh/eerimoq/pumbaa
