:mod:`re` --- Regular expression operations
===========================================

.. module:: re
   :synopsis: Regular expression operations.

----------------------------------------------
